import React, { useState, useEffect } from 'react';
import api from '../services/api';
import '../styles/Table.css';

const Patients = () => {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newPatient, setNewPatient] = useState({ firstName: '', lastName: '', email: '', phone: '', dob: '' });

  useEffect(() => {
    // Mock Data
    setPatients([
      { id: 1, firstName: 'John', lastName: 'Doe', email: 'john@example.com', phone: '555-1234', dob: '1990-01-01' },
      { id: 2, firstName: 'Jane', lastName: 'Smith', email: 'jane@example.com', phone: '555-5678', dob: '1985-05-12' }
    ]);
    setLoading(false);
  }, []);

  const handleAddSubmit = (e) => {
    e.preventDefault();
    setPatients([...patients, { ...newPatient, id: Date.now() }]);
    setShowAddForm(false);
  };

  const filteredPatients = patients.filter(p => 
    p.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.phone.includes(searchTerm)
  );

  return (
    <div>
      <div className="page-header">
        <h2>Patient Management</h2>
        <button className="btn-add" onClick={() => setShowAddForm(!showAddForm)}>{showAddForm ? 'Cancel' : '+ New Patient'}</button>
      </div>
      {showAddForm && (
        <div style={{ marginBottom: '20px', padding: '20px', background: 'white', borderRadius: '8px' }}>
          <h4>Register New Patient</h4>
          <form onSubmit={handleAddSubmit} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
            <input placeholder="First Name" className="form-input" value={newPatient.firstName} onChange={e => setNewPatient({...newPatient, firstName: e.target.value})} required />
            <input placeholder="Last Name" className="form-input" value={newPatient.lastName} onChange={e => setNewPatient({...newPatient, lastName: e.target.value})} required />
            <input placeholder="Email" className="form-input" value={newPatient.email} onChange={e => setNewPatient({...newPatient, email: e.target.value})} />
            <input placeholder="Phone" className="form-input" value={newPatient.phone} onChange={e => setNewPatient({...newPatient, phone: e.target.value})} required />
            <input type="date" className="form-input" value={newPatient.dob} onChange={e => setNewPatient({...newPatient, dob: e.target.value})} required />
            <button type="submit" className="btn-primary" style={{ gridColumn: 'span 2' }}>Save Patient</button>
          </form>
        </div>
      )}
      <input type="text" placeholder="Search..." className="search-bar" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} style={{ marginBottom: '15px' }} />
      <div className="data-table-container">
        <table className="data-table">
          <thead><tr><th>Name</th><th>Contact</th><th>DOB</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {filteredPatients.map((patient) => (
              <tr key={patient.id}>
                <td>{patient.firstName} {patient.lastName}</td>
                <td>{patient.phone}<br/><small>{patient.email}</small></td>
                <td>{patient.dob}</td>
                <td><span className="status-badge status-active">Active</span></td>
                <td><button className="btn-sm">View</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Patients;
import React, { useState } from 'react';
import '../styles/Billing.css';
import '../styles/Table.css';

const Billing = () => {
  const [cart, setCart] = useState([]);
  const items = [{ id: 1, name: 'Consultation Fee', price: 50.00 }, { id: 2, name: 'Paracetamol', price: 5.00 }];
  
  const addToCart = (item) => setCart([...cart, item]);
  const total = cart.reduce((acc, item) => acc + item.price, 0).toFixed(2);

  return (
    <div className="billing-container">
      <div className="billing-card">
        <h3>Add Items</h3>
        {items.map(i => <button key={i.id} className="btn-sm" onClick={() => addToCart(i)}>{i.name} (${i.price})</button>)}
      </div>
      <div className="billing-card">
        <div className="invoice-header"><h4>Invoice</h4></div>
        <ul className="invoice-item-list">{cart.map((i, idx) => <li key={idx} className="invoice-item"><span>{i.name}</span><span>${i.price}</span></li>)}</ul>
        <div className="invoice-total">Total: ${total}</div>
      </div>
    </div>
  );
};
export default Billing;
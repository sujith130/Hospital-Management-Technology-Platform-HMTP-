import React from 'react';
import '../styles/Table.css';

const Inventory = () => {
  const medicines = [
    { id: 1, name: 'Paracetamol 500mg', batch: 'B101', stock: 150, expiry: '2026-12-01', price: 5.00 },
    { id: 2, name: 'Amoxicillin 250mg', batch: 'B102', stock: 8, expiry: '2025-08-15', price: 12.50 },
  ];

  return (
    <div>
      <div className="page-header"><h2>Pharmacy Inventory</h2><button className="btn-add">+ Add Medicine</button></div>
      <div className="data-table-container">
        <table className="data-table">
          <thead><tr><th>Name</th><th>Batch</th><th>Expiry</th><th>Stock</th><th>Price</th></tr></thead>
          <tbody>
            {medicines.map((item) => (
              <tr key={item.id}>
                <td>{item.name}</td><td>{item.batch}</td><td>{item.expiry}</td>
                <td><span className={`status-badge ${item.stock < 10 ? 'status-inactive' : 'status-active'}`} style={item.stock < 10 ? {color: 'red'} : {}}>{item.stock}</span></td>
                <td>${item.price.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
export default Inventory;
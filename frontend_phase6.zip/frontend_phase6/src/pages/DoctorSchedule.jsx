import React, { useState, useEffect } from 'react';
import '../styles/Schedule.css';

const DoctorSchedule = () => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [slots, setSlots] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState(null);

  useEffect(() => {
    const times = ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00'];
    setSlots(times.map(time => ({ id: time, time, status: 'available' })));
  }, [selectedDate]);

  const handleSlotClick = (slot) => {
    if (slot.status === 'booked') return;
    setSelectedSlot(slot);
  };

  const confirmBooking = () => {
    setSlots(slots.map(s => s.time === selectedSlot.time ? { ...s, status: 'booked', patientName: 'John Doe' } : s));
    setSelectedSlot(null);
    alert("Booked!");
  };

  return (
    <div className="schedule-container">
      <div className="date-header"><h3>{selectedDate}</h3></div>
      <div className="slots-grid">
        {slots.map((slot) => (
          <div key={slot.time} className={`time-slot ${slot.status === 'available' ? 'slot-available' : 'slot-booked'}`} onClick={() => handleSlotClick(slot)}>
            <span className="time-label">{slot.time}</span>
            <span className="slot-status">{slot.status}</span>
          </div>
        ))}
      </div>
      {selectedSlot && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h3>Book {selectedSlot.time}</h3>
            <button className="btn-primary" onClick={confirmBooking}>Confirm</button>
            <button className="btn-sm" onClick={() => setSelectedSlot(null)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default DoctorSchedule;